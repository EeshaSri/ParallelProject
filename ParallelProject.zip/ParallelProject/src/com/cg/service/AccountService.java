package com.cg.service;


import java.util.List;
import com.cg.bean.Account;
import com.cg.dao.AccountData;
import com.cg.ui.FrontEnd;

public class AccountService {
	
	FrontEnd frontEnd=new FrontEnd();
	AccountData accountData=new AccountData();
	
	
	public void createAccount(Account account) {
		accountData.storeData(account);
		
	}
	public double showBalance(int accountNumber) {
		List<Account> accountList1=accountData.returnStoreData();
		for(Account account:accountList1) {
			if(accountNumber==account.getAccountNumber()) {
				return account.getBalance();
			}
		}
		
		return 23;
	}
			
}
