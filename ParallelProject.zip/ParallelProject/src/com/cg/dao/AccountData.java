package com.cg.dao;

import java.util.ArrayList;
import java.util.List;
import com.cg.bean.Account;

public class AccountData {
	
	public List<Account> accountList=new ArrayList<>();
	
	public List<Account> getAccountList() {									//getter
		return accountList;
	}

	public void setAccountList(List<Account> accountList) {					//setter
		this.accountList = accountList;
	}

	@Override
	public String toString() {												//toString
		return "AccountData [accountList=" + accountList + "]";
	}

	public void storeData(Account account) {								//method to add data on ArrayList
		accountList.add(account);
		
		System.out.println(accountList);
	}
	
	public List<Account> returnStoreData(){									//method to return data in ArrayList
		return accountList;
	}

	
}
