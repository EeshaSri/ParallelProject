package com.cg.ui;

import java.util.Scanner;
import com.cg.bean.Account;
import com.cg.service.AccountService;

public class FrontEnd {
	
	Scanner scanner=new Scanner(System.in);
	Account account=new Account();
	
	
	public void display() {
		
		System.out.println("1.Create Account");
		System.out.println("2.Show Balance");
		System.out.println("3.Deposit Amount");
		System.out.println("4.Withdraw Amount");
		System.out.println("5.Transfer Cash");
		System.out.println("6.Show Transactions");
		System.out.println("7.Exit");
		System.out.println("Enter your choice");
		
	}
	
	public void switchCase() {
		AccountService accountService=new AccountService();
		switch(scanner.nextInt()) {
		
		case 1:System.out.println("Enter your AccountId");
				account.setAccountNumber(scanner.nextInt());
				System.out.println("Enter your name");
				account.setName(scanner.next());
				System.out.println("Enter your Amount");
				account.setBalance(scanner.nextDouble());
				accountService.createAccount(account);
			break;
			
		case 2:System.out.println("enter your AccountId");
				int accountNumber=scanner.nextInt();
				System.out.println(accountService.showBalance(accountNumber));
				break;
			
		case 3:System.out.println("3");
			break;
			
		case 4:System.out.println("4");
			break;
			
		case 5:System.out.println("5");
			break;
			
		case 6:System.out.println("6");
			break;
			
		case 7:scanner.close();
			   System.out.println("Thank You. Visit Again.");
			   System.exit(0);
			  
		}
		
		
	}

}
